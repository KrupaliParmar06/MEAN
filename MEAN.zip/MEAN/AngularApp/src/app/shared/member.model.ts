export class Member {
    _id:string='';
    FirstName:string='';
    LastName:string='';
    ContactNo:string='';
    EmailId:string='';
    Password:string='';
    Gender:string='';
    Status:string='';
}
